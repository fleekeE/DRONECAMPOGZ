from droneblocks.DroneBlocksTello import DroneBlocksTello
import droneblocks
if __name__ == '__main__':
    db_tello = DroneBlocksTello()
    print(droneblocks.__version__)
    print("If you see this, your install worked")