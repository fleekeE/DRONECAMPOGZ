

class LandException(Exception):
    """
    Custom exception to instruct the tello_script_runner that a user script
    would like to land.
    """
    pass